define(
"dojo/cldr/nls/da/currency", //begin v1.x content
{
	"HKD_displayName": "Hongkong dollar",
	"CHF_displayName": "Schweizisk franc",
	"JPY_symbol": "JP¥",
	"CAD_displayName": "Canadisk dollar",
	"HKD_symbol": "HK$",
	"CNY_displayName": "Kinesisk yuan renminbi",
	"USD_symbol": "$",
	"AUD_displayName": "Australsk dollar",
	"JPY_displayName": "Japansk yen",
	"CAD_symbol": "CA$",
	"USD_displayName": "Amerikansk dollar",
	"EUR_symbol": "€",
	"CNY_symbol": "CN¥",
	"GBP_displayName": "Britisk pund",
	"GBP_symbol": "£",
	"AUD_symbol": "AU$",
	"EUR_displayName": "Euro"
}
//end v1.x content
);