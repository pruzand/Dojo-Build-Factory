define(
"dijit/nls/sl/loading", ({
	loadingState: "Nalaganje ...",
	errorState: "Oprostite, prišlo je do napake."
})
);
