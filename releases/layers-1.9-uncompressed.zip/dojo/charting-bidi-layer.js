require({cache:{
'dojox/charting/bidi/widget/Legend':function(){
define(["dojo/_base/declare", "dojo/dom", "dijit/registry", "dojo/_base/connect", "dojo/_base/array", "dojo/query"],
	function(declare, dom, widgetManager, hub, arrayUtil, query){
	// module:
	//		dojox/charting/bidi/widget/Legend	
	function validateTextDir(textDir){
		return /^(ltr|rtl|auto)$/.test(textDir) ? textDir : null;
	}
	
	return declare(null, {
		postMixInProperties: function(){
			// summary:
			//		Connect the setter of textDir legend to setTextDir of the chart,
			//		so _setTextDirAttr of the legend will be called after setTextDir of the chart is called.
			// tags:
			//		private

			// find the chart that is the owner of this legend, use it's
			// textDir
			if(!this.chart){
				if(!this.chartRef){ return; }
				var chart = widgetManager.byId(this.chartRef);
				if(!chart){
					var node = dom.byId(this.chartRef);
					if(node){
						chart = widgetManager.byNode(node);
					}else{
						return;
					}
				}
				this.textDir = chart.chart.textDir;
				hub.connect(chart.chart, "setTextDir", this, "_setTextDirAttr");

			}else{
				this.textDir = this.chart.textDir;
				hub.connect(this.chart, "setTextDir", this, "_setTextDirAttr");

			}
		},

		_setTextDirAttr: function(/*String*/ textDir){
			// summary:
			//		Setter for textDir.
			// description:
			//		Users shouldn't call this function; they should be calling
			//		set('textDir', value)
			// tags:
			//		private

			// only if new textDir is different from the old one
			if(validateTextDir(textDir) != null){
				if(this.textDir != textDir){
					this._set("textDir", textDir);
					// get array of all the labels
					var legendLabels = query(".dojoxLegendText", this._tr);
						// for every label calculate it's new dir.
						arrayUtil.forEach(legendLabels, function(label){
							label.dir = this.getTextDir(label.innerHTML, label.dir);
					}, this);
				}
			}
		}
	});	
});

},
'dojox/charting/bidi/Chart':function(){
define(["dojox/main", "dojo/_base/declare", "dojo/_base/lang", "dojo/dom-style", "dojo/_base/array", "dojo/sniff",
	"dojo/dom","dojo/dom-construct",
	"dojox/gfx", "dojox/gfx/_gfxBidiSupport", "../axis2d/common", "dojox/string/BidiEngine",
	"dojox/lang/functional","dojo/dom-attr","./_bidiutils"],
	function(dojox, declare, lang, domStyle, arr, has, dom, domConstruct, g, gBidi, da, BidiEngine, df, domAttr,utils){
	// module:
	//		dojox/charting/bidi/Chart							
	var bidiEngine = new BidiEngine();
	var dc = lang.getObject("charting", true, dojox);
	function validateTextDir(textDir){
		return /^(ltr|rtl|auto)$/.test(textDir) ? textDir : null;
	};
	
	return declare(null, {
		// textDir: String
		//		Bi-directional support,	the main variable which is responsible for the direction of the text.
		//		The text direction can be different than the GUI direction by using this parameter.
		//		Allowed values:
		//
		//		1. "ltr"
		//		2. "rtl"
		//		3. "auto" - contextual the direction of a text defined by first strong letter.
		//
		//		By default is as the page direction.
		textDir:"",
		
		// dir: String
		//		Mirroring support,	the main variable which is responsible for the direction of the chart.
		//
		//		Allowed values:
		//		1. "ltr"
		//		2. "rtl"
		//
		//		By default is ltr.
		dir: "",
		isMirrored: false,
		
		getTextDir: function(text){
			// summary:
			//		Return direction of the text. 
			// description:
			//		If textDir is ltr or rtl returns the value.
			//		If it's auto, calls to another function that responsible 
			//		for checking the value, and defining the direction.			
			// text:
			//		Used in case textDir is "auto", this case the direction is according to the first
			//		strong (directionally - which direction is strong defined) letter.
			// tags:
			//		protected.
			var textDir = this.textDir == "auto" ? bidiEngine.checkContextual(text) : this.textDir;
			// providing default value
			if(!textDir){
				textDir = domStyle.get(this.node, "direction");
			}
			return textDir;
		},

		postscript: function(node,args){
			// summary:
			//		Kicks off chart instantiation.
			// description:
			//		Used for setting the textDir of the chart. 
			// tags:
			//		private

			// validate textDir
			var textDir = args ? (args["textDir"] ? validateTextDir(args["textDir"]) : "") : "";
			// if textDir wasn't defined or was defined wrong, apply default value
			textDir = textDir ? textDir : domStyle.get(this.node, "direction");
			this.textDir = textDir;

			this.surface.textDir = textDir;
			
			// two data structures, used for storing data for further enablement to change
			// textDir dynamically
			this.htmlElementsRegistry = [];
			this.truncatedLabelsRegistry = [];
			// chart mirroring starts
			var chartDir = "ltr";
			if(domAttr.has(node, "direction")){
				chartDir = domAttr.get(node, "direction");
			}
			this.setDir(args ? (args.dir ? args.dir: chartDir) : chartDir);
			// chart mirroring ends
		},

		setTextDir: function(newTextDir, obj){
			// summary:
			//		Setter for the textDir attribute.
			// description:
			//		Allows dynamically set the textDir, goes over all the text-children and  
			//		updates their base text direction.
			// tags:
			//		public
		
			if(newTextDir == this.textDir){
				return this;
			}
			if(validateTextDir(newTextDir) != null){
				this.textDir = newTextDir;
				
				// set automatically all the gfx objects that were created by this surface
				// (groups, text objects)
				this.surface.setTextDir(newTextDir);
			
				// truncated labels that were created with gfx creator need to recalculate dir
				// for case like: "111111A" (A stands for bidi character) and the truncation
				// is "111..." If the textDir is auto, the display should be: "...111" but in gfx
				// case we will get "111...". Because this.surface.setTextDir will calculate the dir of truncated
				// label, which value is "111..." but th real is "111111A".
				// each time we created a gfx truncated label we stored it in the truncatedLabelsRegistry, so update now 
				// the registry.
				if(this.truncatedLabelsRegistry && newTextDir == "auto"){
					arr.forEach(this.truncatedLabelsRegistry, function(elem){
						var tDir = this.getTextDir(elem["label"]);
						if(elem["element"].textDir != tDir){
							elem["element"].setShape({textDir: tDir});
						}
					}, this);
				}
				
				// re-render axes with html labels. for recalculation of the labels
				// positions etc.
				// create array of keys for all the axis in chart 
				var axesKeyArr = df.keys(this.axes);
				if(axesKeyArr.length > 0){
					// iterate over the axes, and for each that have html labels render it.
					arr.forEach(axesKeyArr, function(key, index, arr){
						// get the axis 
						var axis = this.axes[key];
						// if the axis has html labels 
						if(axis.htmlElements[0]){
							axis.dirty = true;
							axis.render(this.dim, this.offsets);
						}
					},this);
					
					// recreate title
					if(this.title){
						var forceHtmlLabels = (g.renderer == "canvas"),
							labelType = forceHtmlLabels || !has("ie") && !has("opera") ? "html" : "gfx",
							tsize = g.normalizedLength(g.splitFontString(this.titleFont).size);
						// remove the title
						domConstruct.destroy(this.chartTitle);
						this.chartTitle =null;
						// create the new title
						this.chartTitle = da.createText[labelType](
							this,
							this.surface,
							this.dim.width/2,
							this.titlePos=="top" ? tsize + this.margins.t : this.dim.height - this.margins.b,
							"middle",
							this.title,
							this.titleFont,
							this.titleFontColor
						);
					}				
				}else{
					// case of pies, spiders etc.
					arr.forEach(this.htmlElementsRegistry, function(elem, index, arr){
						var tDir = newTextDir == "auto" ? this.getTextDir(elem[4]) : newTextDir;
						if(elem[0].children[0] && elem[0].children[0].dir != tDir){
							domConstruct.destroy(elem[0].children[0]);
							elem[0].children[0] = da.createText["html"]
									(this, this.surface, elem[1], elem[2], elem[3], elem[4], elem[5], elem[6]).children[0];
						}
					},this);
				}
			}
			return this;
		},
		
		setDir : function(dir){
			// summary:
			//		Setter for the dir attribute.
			// description:
			//		Allows dynamically set the dri attribute, which will used to
			//		updates the chart rendering direction.
			//	dir : the desired chart direction [rtl: for right to left ,ltr: for left to right]
 
			if(dir == "rtl" || dir == "ltr"){
				if(this.dir != dir){
					this.isMirrored = true;
					this.dirty = true;
				}
				this.dir = dir;
			}			
			return this; 
		},
		
		isRightToLeft: function(){
			// summary:
			//		check the direction of the chart.
			// description:
			//		check the dir attribute to determine the rendering direction
			//		of the chart.
			return this.dir == "rtl";
        },
        
		applyMirroring: function(plot, dim, offsets){
			// summary:
			//		apply the mirroring operation to the current chart plots.
			//
			utils.reverseMatrix(plot, dim, offsets, this.dir == "rtl");
			//force the direction of the node to be ltr to properly render the axes and the plots labels.
			domStyle.set(this.node, "direction", "ltr");
			return this;
		},

		formatTruncatedLabel: function(element, label, labelType){
			this.truncateBidi(element, label, labelType);
		},

		truncateBidi: function(elem, label, labelType){
			// summary:
			//		Enables bidi support for truncated labels.
			// description:
			//		Can be two types of labels: html or gfx.
			//
			//		####gfx labels:
			//
			//		Need to be stored in registry to be used when the textDir will be set dynamically.
			//		Additional work on truncated labels is needed for case as 111111A (A stands for "bidi" character rtl directioned).
			//		let's say in this case the truncation is "111..." If the textDir is auto, the display should be: "...111" but in gfx
			//		case we will get "111...". Because this.surface.setTextDir will calculate the dir of truncated
			//		label, which value is "111..." but th real is "111111A".
			//		each time we created a gfx truncated label we store it in the truncatedLabelsRegistry.
			//
			//		####html labels:
			//
			//		no need for repository (stored in another place). Here we only need to update the current dir according to textDir.
			// tags:
			//		private
		
			if(labelType == "gfx"){
				// store truncated gfx labels in the data structure.
				this.truncatedLabelsRegistry.push({element: elem, label: label});
				if(this.textDir == "auto"){
					elem.setShape({textDir: this.getTextDir(label)});
				}
			}
			if(labelType == "html" && this.textDir == "auto"){
				elem.children[0].dir = this.getTextDir(label);
			}
		},
		
		render: function(){
			this.inherited(arguments);
			this.isMirrored = false;
			return this;
		},
		
		_resetLeftBottom: function(axis){
			if(axis.vertical && this.isMirrored){
				axis.opt.leftBottom = !axis.opt.leftBottom;
			}
		}		
	});
});


},
'dojox/charting/bidi/action2d/ZoomAndPan':function(){
define(["dojo/_base/declare"],
	function(declare){
	// module:
	//		dojox/charting/bidi/action2d/ZoomAndPan	
	return declare(null, {
		_getDelta: function(event){
			var delta = this.inherited(arguments);
			return delta * (this.chart.isRightToLeft()? -1 : 1);				
		}
	});
});

},
'dojox/charting/bidi/widget/Chart':function(){
define(["dojo/_base/declare"],
	function(declare){
	// module:
	//		dojox/charting/bidi/widget/Chart						
	function validateTextDir(textDir){
		return /^(ltr|rtl|auto)$/.test(textDir) ? textDir : null;
	}
	
	return declare(null, {
		postMixInProperties: function(){
			// set initial textDir of the chart, if passed in the creation use that value
			// else use default value, following the GUI direction, this.chart doesn't exist yet
			// so can't use set("textDir", textDir). This passed to this.chart in it's future creation.
			this.textDir = this.params["textDir"] ? this.params["textDir"] : this.params["dir"];
		},
	
		_setTextDirAttr: function(/*String*/ textDir){
			if(validateTextDir(textDir) != null){
				this._set("textDir", textDir);
				this.chart.setTextDir(textDir);
			}
		},
		
		_setDirAttr: function(/*String*/ dir){
			this._set("dir", dir);
			this.chart.setDir(dir);			
		}
	});	
});

},
'dojox/charting/bidi/axis2d/Default':function(){
define(["dojo/_base/declare", "dojo/dom-style"],
	function(declare, domStyle){
	// module:
	//		dojox/charting/bidi/axis2d/Default			
	return declare(null, {
		labelTooltip: function(elem, chart, label, truncatedLabel, font, elemType){
			// additional preprocessing of the labels, needed for rtl base text direction in LTR
			// GUI, or for ltr base text direction for RTL GUI.

			var isChartDirectionRtl = (domStyle.get(chart.node,"direction") == "rtl");
			var isBaseTextDirRtl = (chart.getTextDir(label) == "rtl");

			if(isBaseTextDirRtl && !isChartDirectionRtl){
				label = "<span dir='rtl'>" + label +"</span>";
			}
			if(!isBaseTextDirRtl && isChartDirectionRtl){
				label = "<span dir='ltr'>" + label +"</span>";
			}
			this.inherited(arguments);
		},
		
		_isRtl: function(){
			return this.chart.isRightToLeft();
		}
	});
});


},
'dojox/charting/bidi/action2d/Tooltip':function(){
define(["dojo/_base/declare", "dojo/dom-style"],
	function(declare, domStyle){
	// module:
	//		dojox/charting/bidi/action2d/Tooltip		
	return declare(null, {
		_recheckPosition: function(obj,rect,position){
			if(!this.chart.isRightToLeft()){
				return;
			}
			var shift = this.chart.offsets.l - this.chart.offsets.r;
			if(obj.element == "marker"){
				rect.x = this.chart.dim.width - obj.cx + shift;
				position[0] = "before-centered";
				position[1] = "after-centered";
			}
			else if(obj.element == "circle"){
				rect.x = this.chart.dim.width - obj.cx - obj.cr + shift;
			}
			else if(obj.element == "bar" || obj.element == "column"){
				rect.x = this.chart.dim.width - rect.width - rect.x + shift;
				if(obj.element == "bar"){
					position[0] = "before-centered";
					position[1] = "after-centered";
				}
			}
			else if(obj.element == "candlestick"){
				rect.x = this.chart.dim.width + shift - obj.x;
			}
		},
		
		_format: function(tooltip){
			var isChartDirectionRtl = (domStyle.get(this.chart.node, "direction") == "rtl");
			var isBaseTextDirRtl = (this.chart.getTextDir(tooltip) == "rtl");
			if(isBaseTextDirRtl && !isChartDirectionRtl){
				return "<span dir = 'rtl'>" + tooltip +"</span>";
			}
			else if(!isBaseTextDirRtl && isChartDirectionRtl){
				return "<span dir = 'ltr'>" + tooltip +"</span>";
			}else{
				return tooltip;
			}
		}
	});
});


},
'dojox/charting/bidi/_bidiutils':function(){
  define ({
		reverseMatrix: function(plot, dim, offsets, rtl){
			//summary:
			//	reverse the underlying matrix of the plots to perform the mirroring behavior.
			//plot:
			//  the plot which has the matrix to be reversed.
			//dim:
			//  the dimension (width,height) of the chart.
			//offsets:
			//  the offsets of the chart
			var shift = offsets.l - offsets.r;
			var xx = rtl? -1 : 1;
			var xy = 0;
			var yx = 0;
			var yy = 1;
			var dx = rtl? dim.width + shift : 0;
			var dy = 0;
			if(plot.matrix){
				xx = xx * Math.abs(plot.matrix.xx);
				yy = plot.matrix.yy;
				xy = plot.matrix.xy;
				yx = plot.matrix.yx;
				dy = plot.matrix.xy;
			}
			plot.setTransform({xx: xx, xy: xy, yx: yx, yy: yy, dx: dx, dy: dy});
 	}
 });

},
'dojox/charting/bidi/Chart3D':function(){
define(["dojo/_base/declare", "dojo/dom-style", "dojo/dom-attr", "./_bidiutils"],
	function(declare, domStyle, domAttr, utils){
	// module:
	//		dojox/charting/bidi/Chart3D
	return declare(null, {
		// direction: String
		//		Mirroring support,	the main variable which is responsible for the direction of the chart.
		//
		//		Allowed values:
		//		1. "ltr"
		//		2. "rtl"
		//
		//		By default is ltr.
		direction: "",
		isMirrored: false,
		
		postscript: function(node, lights, camera, theme, direction){
			// summary:
			//		The keyword arguments that can be passed in a Chart constructor.
			//
			// node: Node
			//		The DOM node to construct the chart on.
			// lights:
			//		Lighting properties for the 3d scene
			// camera: Object
			//		Camera properties describing the viewing camera position.
			// theme: Object
			//		Charting theme to use for coloring chart elements.
			// direction:String
			//		the direction used to render the chart values[rtl/ltr]
			var chartDir = "ltr";
			if(domAttr.has(node, "direction")){
				chartDir = domAttr.get(node, "direction");
			}
			this.chartBaseDirection = direction ? direction : chartDir;
		},
		generate: function(){
			this.inherited(arguments);
			this.isMirrored = false;
			return this;
		},
		applyMirroring: function(plot, dim, offsets){
			// summary:
			//		apply the mirroring operation to the current chart plots.
			//
			if(this.isMirrored){
				utils.reverseMatrix(plot, dim, offsets, this.dir == "rtl");
			}
			//force the direction of the node to be ltr to properly render the axes and the plots labels.
			domStyle.set(this.node, "direction", "ltr");
			return this;
		},
		setDir: function(dir){
			// summary:
			//		Setter for the chartBaseDirection attribute.
			// description:
			//		Allows dynamically set the chartBaseDirection attribute, which will used to  
			//		updates the chart rendering direction.
			//	dir : the desired chart direction [rtl: for right to left ,ltr: for left to right]
			if(dir == "rtl" || dir == "ltr"){
				if(this.dir != dir){
					this.isMirrored = true;
				}
				this.dir = dir;
			}
			return this; 
		},
		isRightToLeft: function(){
			// summary:
			//		check the Direction of the chart.
			// description:
			//		check the chartBaseDirection attribute to determine the rendering direction
			//		of the chart.
			return this.dir == "rtl";
        }
	});
});


}}});
define("dojo/charting-bidi-layer", [], 1);
