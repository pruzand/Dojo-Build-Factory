define(
"dojo/cldr/nls/de/roc", //begin v1.x content
{
	"field-second": "Sekunde",
	"field-year-relative+-1": "Letztes Jahr",
	"field-week": "Woche",
	"field-month-relative+-1": "Letzter Monat",
	"field-day-relative+-1": "Gestern",
	"field-day-relative+-2": "Vorgestern",
	"field-year": "Jahr",
	"field-week-relative+0": "Diese Woche",
	"field-week-relative+1": "Nächste Woche",
	"field-minute": "Minute",
	"field-week-relative+-1": "Letzte Woche",
	"field-day-relative+0": "Heute",
	"field-hour": "Stunde",
	"field-day-relative+1": "Morgen",
	"field-day-relative+2": "Übermorgen",
	"field-day": "Tag",
	"field-month-relative+0": "Dieser Monat",
	"field-month-relative+1": "Nächster Monat",
	"field-dayperiod": "Tageshälfte",
	"field-month": "Monat",
	"field-era": "Epoche",
	"field-year-relative+0": "Dieses Jahr",
	"field-year-relative+1": "Nächstes Jahr",
	"eraAbbr": [
		"Before R.O.C.",
		"Minguo"
	],
	"field-weekday": "Wochentag",
	"field-zone": "Zone"
}
//end v1.x content
);