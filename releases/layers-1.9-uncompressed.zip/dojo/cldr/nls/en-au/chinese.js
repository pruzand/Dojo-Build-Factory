define(
"dojo/cldr/nls/en-au/chinese", //begin v1.x content
{
	"timeFormat-long": "h:mm:ss a z",
	"timeFormat-medium": "h:mm:ss a",
	"timeFormat-short": "h:mm a",
	"timeFormat-full": "h:mm:ss a zzzz"
}
//end v1.x content
);