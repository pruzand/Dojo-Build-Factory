define(
"dijit/nls/he/loading", ({
	loadingState: "טעינה...‏",
	errorState: "אירעה שגיאה"
})
);
