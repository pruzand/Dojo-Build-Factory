define(
"dijit/form/nls/sv/validate", ({
	invalidMessage: "Angivet värde är inte giltigt.",
	missingMessage: "Värdet krävs.",
	rangeMessage: "Värdet ligger utanför intervallet."
})
);
