//>>built
define("dijit/form/nls/he/ComboBox",{previousMessage:"\u05d4\u05d0\u05e4\u05e9\u05e8\u05d5\u05d9\u05d5\u05ea \u05d4\u05e7\u05d5\u05d3\u05de\u05d5\u05ea",nextMessage:"\u05d0\u05e4\u05e9\u05e8\u05d5\u05d9\u05d5\u05ea \u05e0\u05d5\u05e1\u05e4\u05d5\u05ea"});
//# sourceMappingURL=ComboBox.js.map