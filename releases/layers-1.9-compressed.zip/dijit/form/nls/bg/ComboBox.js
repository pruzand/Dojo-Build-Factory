//>>built
define("dijit/form/nls/bg/ComboBox",{previousMessage:"\u041f\u0440\u0435\u0434\u0438\u0448\u043d\u0438 \u0438\u0437\u0431\u043e\u0440\u0438",nextMessage:"\u041f\u043e\u0432\u0435\u0447\u0435 \u0438\u0437\u0431\u043e\u0440\u0438"});
//# sourceMappingURL=ComboBox.js.map