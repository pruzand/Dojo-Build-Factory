//>>built
define("dijit/form/nls/sk/validate",{invalidMessage:"Zadan\u00e1 hodnota nie je platn\u00e1.",missingMessage:"T\u00e1to hodnota je povinn\u00e1.",rangeMessage:"T\u00e1to hodnota je mimo rozsah."});
//@ sourceMappingURL=validate.js.map