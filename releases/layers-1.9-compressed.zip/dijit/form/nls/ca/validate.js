//>>built
define("dijit/form/nls/ca/validate",{invalidMessage:"El valor introdu\u00eft no \u00e9s v\u00e0lid",missingMessage:"Aquest valor \u00e9s necessari",rangeMessage:"Aquest valor \u00e9s fora de l'interval"});
//@ sourceMappingURL=validate.js.map