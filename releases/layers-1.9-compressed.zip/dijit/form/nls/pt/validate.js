//>>built
define("dijit/form/nls/pt/validate",{invalidMessage:"O valor inserido n\u00e3o \u00e9 v\u00e1lido.",missingMessage:"Este valor \u00e9 necess\u00e1rio.",rangeMessage:"Este valor est\u00e1 fora do intervalo. "});
//# sourceMappingURL=validate.js.map