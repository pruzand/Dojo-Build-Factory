//>>built
define("dijit/form/nls/th/Textarea",{iframeEditTitle:"\u0e1e\u0e37\u0e49\u0e19\u0e17\u0e35\u0e48\u0e41\u0e01\u0e49\u0e44\u0e02",iframeFocusTitle:"\u0e01\u0e23\u0e2d\u0e1a\u0e1e\u0e37\u0e49\u0e19\u0e17\u0e35\u0e48\u0e41\u0e01\u0e49\u0e44\u0e02"});
//@ sourceMappingURL=Textarea.js.map