//>>built
define("dijit/form/nls/nl/Textarea",{iframeEditTitle:"veld bewerken",iframeFocusTitle:"veldkader bewerken"});
//# sourceMappingURL=Textarea.js.map