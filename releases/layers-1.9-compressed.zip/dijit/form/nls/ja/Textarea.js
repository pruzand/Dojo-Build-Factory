//>>built
define("dijit/form/nls/ja/Textarea",{iframeEditTitle:"\u7de8\u96c6\u57df",iframeFocusTitle:"\u7de8\u96c6\u57df\u30d5\u30ec\u30fc\u30e0"});
//@ sourceMappingURL=Textarea.js.map