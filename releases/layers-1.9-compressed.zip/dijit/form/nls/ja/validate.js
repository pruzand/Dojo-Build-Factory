//>>built
define("dijit/form/nls/ja/validate",{invalidMessage:"\u5165\u529b\u3057\u305f\u5024\u306f\u7121\u52b9\u3067\u3059\u3002",missingMessage:"\u3053\u306e\u5024\u306f\u5fc5\u9808\u3067\u3059\u3002",rangeMessage:"\u3053\u306e\u5024\u306f\u7bc4\u56f2\u5916\u3067\u3059\u3002"});
//@ sourceMappingURL=validate.js.map