//>>built
define("dijit/_editor/nls/pt-pt/LinkDialog",{createLinkTitle:"Propriedades da liga\u00e7\u00e3o",insertImageTitle:"Propriedades da imagem",url:"URL:",text:"Descri\u00e7\u00e3o:",target:"Destino:",set:"Definir",currentWindow:"Janela actual",parentWindow:"Janela ascendente",topWindow:"Janela superior",newWindow:"Nova janela"});
//# sourceMappingURL=LinkDialog.js.map