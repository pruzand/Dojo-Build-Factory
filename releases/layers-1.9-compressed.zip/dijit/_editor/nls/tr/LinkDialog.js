//>>built
define("dijit/_editor/nls/tr/LinkDialog",{createLinkTitle:"Ba\u011flant\u0131 \u00d6zellikleri",insertImageTitle:"Resim \u00d6zellikleri",url:"URL:",text:"A\u00e7\u0131klama:",target:"Hedef:",set:"Ayarla",currentWindow:"Ge\u00e7erli Pencere",parentWindow:"\u00dcst Pencere",topWindow:"En \u00dcst Pencere",newWindow:"Yeni Pencere"});
//@ sourceMappingURL=LinkDialog.js.map