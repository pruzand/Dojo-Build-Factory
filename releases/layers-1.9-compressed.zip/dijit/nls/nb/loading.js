//>>built
define("dijit/nls/nb/loading",{loadingState:"Laster inn...",errorState:"Det oppsto en feil"});
//# sourceMappingURL=loading.js.map