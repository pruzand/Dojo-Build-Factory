//>>built
define("dijit/nls/hr/loading",{loadingState:"U\u010ditavanje...",errorState:"\u017dao nam je, do\u0161lo je do gre\u0161ke"});
//# sourceMappingURL=loading.js.map