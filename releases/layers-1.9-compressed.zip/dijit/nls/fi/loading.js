//>>built
define("dijit/nls/fi/loading",{loadingState:"Lataus on meneill\u00e4\u00e4n...",errorState:"On ilmennyt virhe."});
//@ sourceMappingURL=loading.js.map