//>>built
define("dijit/nls/he/common",{buttonOk:"\u05d0\u05d9\u05e9\u05d5\u05e8",buttonCancel:"\u05d1\u05d9\u05d8\u05d5\u05dc",buttonSave:"\u05e9\u05de\u05d9\u05e8\u05d4",itemClose:"\u05e1\u05d2\u05d9\u05e8\u05d4"});
//@ sourceMappingURL=common.js.map