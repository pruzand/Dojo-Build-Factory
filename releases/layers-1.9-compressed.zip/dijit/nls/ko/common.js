//>>built
define("dijit/nls/ko/common",{buttonOk:"\ud655\uc778",buttonCancel:"\ucde8\uc18c",buttonSave:"\uc800\uc7a5",itemClose:"\ub2eb\uae30"});
//# sourceMappingURL=common.js.map