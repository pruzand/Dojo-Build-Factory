//>>built
define("dijit/nls/ar/common",{buttonOk:"\u062d\u0633\u0646\u0627",buttonCancel:"\u0627\u0644\u063a\u0627\u0621",buttonSave:"\u062d\u0641\u0638",itemClose:"\u0627\u063a\u0644\u0627\u0642"});
//@ sourceMappingURL=common.js.map