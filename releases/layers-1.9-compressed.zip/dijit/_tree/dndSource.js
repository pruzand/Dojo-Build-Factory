//>>built
define("dijit/_tree/dndSource",["dojo/_base/kernel","dojo/_base/lang","../tree/dndSource"],function(a,b,c){a.deprecated("dijit._tree.dndSource has been moved to dijit.tree.dndSource, use that instead","","2.0");b.setObject("dijit._tree.dndSource",c)});
//@ sourceMappingURL=dndSource.js.map