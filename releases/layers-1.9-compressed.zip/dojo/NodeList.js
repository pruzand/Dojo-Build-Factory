//>>built
define("dojo/NodeList",["./query"],function(a){return a.NodeList});
//@ sourceMappingURL=NodeList.js.map