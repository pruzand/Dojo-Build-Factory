//>>built
define("dojo/_base/query",["../query","./NodeList"],function(a){return a});
//# sourceMappingURL=query.js.map