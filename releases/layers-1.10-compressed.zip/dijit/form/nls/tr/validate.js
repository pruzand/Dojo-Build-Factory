//>>built
define("dijit/form/nls/tr/validate",{invalidMessage:"Girilen de\u011fer ge\u00e7ersiz.",missingMessage:"Bu de\u011fer gerekli.",rangeMessage:"Bu de\u011fer aral\u0131k d\u0131\u015f\u0131nda."});
//# sourceMappingURL=validate.js.map