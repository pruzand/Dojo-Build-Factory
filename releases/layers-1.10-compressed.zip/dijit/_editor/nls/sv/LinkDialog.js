//>>built
define("dijit/_editor/nls/sv/LinkDialog",{createLinkTitle:"L\u00e4nkegenskaper",insertImageTitle:"Bildegenskaper",url:"URL-adress:",text:"Beskrivning:",target:"M\u00e5l:",set:"Anv\u00e4nd",currentWindow:"Aktuellt f\u00f6nster",parentWindow:"\u00d6verordnat f\u00f6nster",topWindow:"\u00d6versta f\u00f6nstret",newWindow:"Nytt f\u00f6nster"});
//# sourceMappingURL=LinkDialog.js.map