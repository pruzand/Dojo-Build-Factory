//>>built
define("dojo/cldr/nls/en-gb/number",{currencyFormat:"\u00a4#,##0.00"});