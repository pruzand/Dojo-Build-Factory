//>>built
define("dijit/nls/ko/loading",{loadingState:"\ub85c\ub4dc \uc911...",errorState:"\uc8c4\uc1a1\ud569\ub2c8\ub2e4. \uc624\ub958\uac00 \ubc1c\uc0dd\ud588\uc2b5\ub2c8\ub2e4."});