//>>built
define("dijit/nls/tr/common",{buttonOk:"Tamam",buttonCancel:"\u0130ptal",buttonSave:"Kaydet",itemClose:"Kapat"});